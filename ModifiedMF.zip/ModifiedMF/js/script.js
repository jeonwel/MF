const btn = document.getElementById("btn");

btn.addEventListener("click", function(){
    window.location = "../html/order2.html";
})